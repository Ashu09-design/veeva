/**
 * build-zip.js
 *
 * Creates a deployment-ready ZIP file for uploading to Veeva Vault.
 * Only includes the files Veeva needs — HTML + veeva-library.js
 *
 * Usage: npm run package
 * Output: dist/veeva-segment-navigation.zip
 */

const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const DIST = path.join(ROOT, "dist");
const ZIP_NAME = "veeva-segment-navigation.zip";

// Files that go into the Veeva ZIP (flat, no subfolders)
const FILES = [
    "veeva-segment-navigation.html",
    "veeva-library.js"
];

// Validate all files exist
for (const file of FILES) {
    const full = path.join(ROOT, file);
    if (!fs.existsSync(full)) {
        console.error("ERROR: Missing file: " + file);
        console.error("Make sure veeva-library.js is downloaded. See README.md step 1.");
        process.exit(1);
    }
}

// Create dist folder
if (!fs.existsSync(DIST)) {
    fs.mkdirSync(DIST);
}

// Build ZIP using PowerShell (works on Windows)
const zipPath = path.join(DIST, ZIP_NAME);

// Remove old zip if exists
if (fs.existsSync(zipPath)) {
    fs.unlinkSync(zipPath);
}

const filePaths = FILES.map(f => '"' + path.join(ROOT, f) + '"').join(", ");
const psCommand = `Compress-Archive -Path ${filePaths} -DestinationPath "${zipPath}"`;

try {
    execSync(`powershell -Command "${psCommand}"`, { stdio: "inherit" });
    console.log("");
    console.log("SUCCESS: " + zipPath);
    console.log("");
    console.log("Upload this ZIP to Veeva Vault as a Multichannel Slide.");
} catch (e) {
    console.error("Failed to create ZIP. Error:", e.message);
    process.exit(1);
}
