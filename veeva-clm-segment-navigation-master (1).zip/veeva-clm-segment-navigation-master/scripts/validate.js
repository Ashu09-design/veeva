/**
 * validate.js
 *
 * Pre-deployment validation script.
 * Checks that the project is correctly configured before packaging.
 *
 * Usage: npm run validate
 */

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
let errors = 0;
let warnings = 0;

function pass(msg) { console.log("  PASS  " + msg); }
function fail(msg) { console.log("  FAIL  " + msg); errors++; }
function warn(msg) { console.log("  WARN  " + msg); warnings++; }

console.log("");
console.log("Veeva CLM Segment Navigation — Validation");
console.log("==========================================");
console.log("");

// 1. Check veeva-library.js exists
const libPath = path.join(ROOT, "veeva-library.js");
if (fs.existsSync(libPath)) {
    const size = fs.statSync(libPath).size;
    if (size > 1000) {
        pass("veeva-library.js exists (" + Math.round(size / 1024) + " KB)");
    } else {
        fail("veeva-library.js is too small (" + size + " bytes) — may be corrupted");
    }
} else {
    fail("veeva-library.js is MISSING — download from https://cdnmc1.vod309.com/clm/release/veeva-library.js");
}

// 2. Check HTML file exists
const htmlPath = path.join(ROOT, "veeva-segment-navigation.html");
if (fs.existsSync(htmlPath)) {
    pass("veeva-segment-navigation.html exists");

    const html = fs.readFileSync(htmlPath, "utf8");

    // 3. Check library is included
    if (html.includes('src="veeva-library.js"')) {
        pass('<script src="veeva-library.js"> tag found');
    } else {
        fail("HTML does not include veeva-library.js — add <script src=\"veeva-library.js\"></script> in <head>");
    }

    // 4. Check for placeholder slide names
    if (html.includes('"slide_1"') || html.includes('"slide_2"')) {
        warn("Placeholder slide names detected (slide_1, slide_2, etc.)");
        warn("Replace with your real Media_File_Name_vod__c values before deploying");
    } else {
        pass("No placeholder slide names found — looks configured");
    }

    // 5. Check debug panel
    if (html.includes('id="debugLog"')) {
        warn("Debug panel is still present — remove before production deployment");
    }

} else {
    fail("veeva-segment-navigation.html is MISSING");
}

// Summary
console.log("");
console.log("------------------------------------------");
if (errors > 0) {
    console.log("RESULT: " + errors + " error(s), " + warnings + " warning(s)");
    console.log("Fix the errors above before packaging.");
    process.exit(1);
} else if (warnings > 0) {
    console.log("RESULT: All checks passed with " + warnings + " warning(s)");
    console.log("Review warnings above. Run 'npm run package' when ready.");
} else {
    console.log("RESULT: All checks passed!");
    console.log("Run 'npm run package' to create the deployment ZIP.");
}
console.log("");
