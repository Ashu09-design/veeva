# Veeva CLM Segment Navigation

A segment-based slide navigation UI for **Veeva CRM CLM presentations**. Reps tap a segment button and the Veeva CLM player jumps to the correct slide — no swiping required.

| Segment | Slides (pages) |
|---------|----------------|
| **A**   | 1, 3, 6, 7     |
| **B**   | 2, 5, 8        |
| **C**   | 4              |

---

## How It Works

```
Rep taps "Segment A"
      ↓
playSegment("A")
      ↓
Looks up segment config → first slide key for A
      ↓
com.veeva.clm.gotoSlide("BrandX_2024_01", "")
      ↓
Veeva CLM player navigates to that slide
```

All slides live in the **same presentation**. The second parameter `""` tells Veeva to stay in the current presentation.

---

## Project Structure

```
veeva/
├── veeva-segment-navigation.html   ← Main UI (this is the CLM slide)
├── veeva-library.js                ← Veeva's official CLM JS library (REQUIRED)
├── package.json                    ← npm scripts for validate & package
├── scripts/
│   ├── build-zip.js                ← Creates deployment ZIP
│   └── validate.js                 ← Pre-deploy checks
├── VEEVA-SEGMENT-HELPER.md         ← Detailed troubleshooting guide
├── .gitignore
└── README.md                       ← You are here
```

---

## Prerequisites

- **Node.js** (v14+) — only needed for the build/validate scripts
- A **Veeva CRM** environment with CLM enabled
- Access to your presentation's **Key Message names** (`Media_File_Name_vod__c` values)

---

## Setup — Step by Step

### Step 1: Clone the repo

```bash
git clone https://github.com/saurabhwebdev/veeva-clm-segment-navigation.git
cd veeva-clm-segment-navigation
```

### Step 2: Verify `veeva-library.js` is present

The repo includes `veeva-library.js` (downloaded from Veeva's CDN). If it's missing or you need to re-download:

```bash
curl -o veeva-library.js https://cdnmc1.vod309.com/clm/release/veeva-library.js
```

This file is **required**. Without it, `com.veeva.clm` doesn't exist and every API call silently fails (Veeva shows no error).

### Step 3: Configure your slide names

Open `veeva-segment-navigation.html` and find the `segments` object (~line 142):

```javascript
// BEFORE — placeholders (WILL NOT WORK in Veeva)
var segments = {
    "A": ["slide_1", "slide_3", "slide_6", "slide_7"],
    "B": ["slide_2", "slide_5", "slide_8"],
    "C": ["slide_4"]
};
```

Replace with your **real Key Message names**:

```javascript
// AFTER — real values from your Veeva CRM
var segments = {
    "A": ["BrandX_2024_01", "BrandX_2024_03", "BrandX_2024_06", "BrandX_2024_07"],
    "B": ["BrandX_2024_02", "BrandX_2024_05", "BrandX_2024_08"],
    "C": ["BrandX_2024_04"]
};
```

#### Where to find your slide names

| Source | Navigation |
|--------|------------|
| **Vault** | Library → Multichannel Slide → **Name** field |
| **CRM (Salesforce)** | `Key_Message_vod__c` object → `Media_File_Name_vod__c` field |
| **SOQL** | `SELECT Media_File_Name_vod__c FROM Key_Message_vod__c WHERE Presentation_vod__c = 'YOUR_ID'` |

> **Slide names are case-sensitive.** `BrandX_01` ≠ `brandx_01`

### Step 4: Validate your setup

```bash
npm run validate
```

This checks:
- `veeva-library.js` exists and isn't corrupted
- The `<script>` tag is present in the HTML
- Placeholder names have been replaced
- Debug panel status

Example output:

```
Veeva CLM Segment Navigation — Validation
==========================================

  PASS  veeva-library.js exists (106 KB)
  PASS  veeva-segment-navigation.html exists
  PASS  <script src="veeva-library.js"> tag found
  PASS  No placeholder slide names found — looks configured
  WARN  Debug panel is still present — remove before production deployment

------------------------------------------
RESULT: All checks passed with 1 warning(s)
```

### Step 5: Build the deployment ZIP

```bash
npm run package
```

This creates `dist/veeva-segment-navigation.zip` containing only the two files Veeva needs:

```
veeva-segment-navigation.zip
├── veeva-segment-navigation.html
└── veeva-library.js
```

### Step 6: Upload to Veeva Vault

1. Go to **Vault → Library**
2. Create or open a **Multichannel Slide** document
3. Upload `dist/veeva-segment-navigation.zip` as the source file
4. Assign it to your presentation
5. Sync to the iPad and test

---

## Debugging

Since the Veeva CLM player on iPad **shows no JavaScript errors**, the HTML includes a built-in **debug panel** (green text on black background at the bottom of the screen).

### Debug messages explained

| Message | Meaning |
|---------|---------|
| `OK: veeva-library.js loaded successfully` | Library is loaded — good |
| `ERROR: com.veeva.clm is UNDEFINED` | **Library is missing** from the ZIP |
| `playSegment('A') → navigating to: BrandX_01` | Button was tapped — working |
| `SUCCESS: gotoSlide('BrandX_01', '') called` | Veeva API was called |
| `ERROR: com.veeva.clm is not available` | Library failed to load |
| `EXCEPTION: ...` | JavaScript error — read the message |

### Remove debug panel for production

Before final deployment, delete this line from the HTML:

```html
<div id="debugLog"></div>
```

And delete the `log()` function and all `log(...)` calls from the `<script>` section.

---

## Customization

### Adding / Removing Segments

Edit the `segments` object in the HTML file:

```javascript
var segments = {
    "A": ["slide_1", "slide_3"],
    "B": ["slide_2", "slide_5"],
    "C": ["slide_4"],
    "D": ["slide_9", "slide_10"]   // ← new segment
};
```

Then add a button in the HTML:

```html
<button class="segment-btn segment-d" onclick="playSegment('D')">Segment D</button>
```

And style it in CSS:

```css
.segment-d { background: #9C27B0; color: #fff; }
```

### Changing segment colors

| Color  | CSS value |
|--------|-----------|
| Red    | `#F44336` |
| Pink   | `#E91E63` |
| Purple | `#9C27B0` |
| Blue   | `#2196F3` |
| Teal   | `#009688` |
| Green  | `#4CAF50` |
| Orange | `#FF9800` |

### Navigating to a different presentation

Change the second parameter from `""` to the target presentation's ID:

```javascript
com.veeva.clm.gotoSlide("slide_key", "other_presentation_id");
```

---

## Troubleshooting

### Nothing happens when buttons are tapped

| # | Check | Fix |
|---|-------|-----|
| 1 | Is `veeva-library.js` in the ZIP? | Run `npm run validate` to check |
| 2 | Are slide names correct? | Verify `Media_File_Name_vod__c` values — they're case-sensitive |
| 3 | Is the ZIP flat (no subfolders)? | Run `npm run package` which creates the correct structure |
| 4 | Are you testing inside Veeva CLM? | The code only works inside the Veeva CLM player, not in a regular browser |

### Debug panel says "com.veeva.clm is UNDEFINED"

`veeva-library.js` is not loading:
1. Make sure it's in the ZIP file
2. Filename must be exact: `veeva-library.js` (lowercase, no typos)
3. Must be at the ZIP root, not in a subfolder

### Debug panel says "SUCCESS" but slide doesn't change

The API call worked but the slide name doesn't match. Verify:
1. The name matches `Media_File_Name_vod__c` **exactly**
2. The slide is in the **same presentation**

### Full troubleshooting guide

See [VEEVA-SEGMENT-HELPER.md](./VEEVA-SEGMENT-HELPER.md) for the complete guide with SOQL queries, iPad-specific fixes, and FAQ.

---

## Veeva CLM API Reference

```javascript
// Navigate to a slide in the current presentation
com.veeva.clm.gotoSlide("slide_key", "");

// Navigate to a slide in a different presentation
com.veeva.clm.gotoSlide("slide_key", "presentation_id");

// Next / Previous slide (standard display order)
com.veeva.clm.nextSlide();
com.veeva.clm.prevSlide();
```

**Official docs:** [Veeva CLM Developer Documentation](https://developer.veevacrm.com/doc/Content/CRM_topics/Veeva/clm-veeva.htm)

---

## npm Scripts

| Command | What it does |
|---------|--------------|
| `npm run validate` | Checks project configuration before packaging |
| `npm run package` | Creates `dist/veeva-segment-navigation.zip` for Vault upload |

---

## License

MIT
