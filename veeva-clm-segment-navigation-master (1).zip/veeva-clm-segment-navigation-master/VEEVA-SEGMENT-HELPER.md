# Veeva CLM Segment Navigation — Setup & Troubleshooting Guide

---

## Why The Previous Code Did Not Work

The original code was **missing the Veeva JavaScript library**. Without it, `com.veeva.clm` does not exist, and every `gotoSlide()` call **silently fails** — Veeva shows no error.

The fix is a single `<script>` tag that must appear **before** your code:

```html
<script src="veeva-library.js"></script>
```

---

## Step-by-Step Setup

### 1. Download the Veeva Library

Download `veeva-library.js` from Veeva's CDN:

```
https://cdnmc1.vod309.com/clm/release/veeva-library.js
```

Save it as `veeva-library.js`.

### 2. Get Your Slide Key Names

You need the **Key Message name** (the `Media_File_Name_vod__c` value) for each slide.

**Where to find it:**

| Source | Path |
|--------|------|
| Vault | Library → Multichannel Slide → **Name** field |
| CRM (Salesforce) | Key_Message_vod__c object → **Media_File_Name_vod__c** field |
| SOQL Query | `SELECT Media_File_Name_vod__c FROM Key_Message_vod__c WHERE Presentation_vod__c = 'YOUR_PRES_ID'` |

### 3. Update the Code

Open `veeva-segment-navigation.html` and replace the placeholder names:

```javascript
// BEFORE (placeholders — will NOT work)
var segments = {
    "A": ["slide_1", "slide_3", "slide_6", "slide_7"],
    "B": ["slide_2", "slide_5", "slide_8"],
    "C": ["slide_4"]
};

// AFTER (example with real names)
var segments = {
    "A": ["BrandX_2024_01", "BrandX_2024_03", "BrandX_2024_06", "BrandX_2024_07"],
    "B": ["BrandX_2024_02", "BrandX_2024_05", "BrandX_2024_08"],
    "C": ["BrandX_2024_04"]
};
```

### 4. Create the ZIP Package

Veeva requires content as a ZIP file. Your ZIP must contain:

```
your-slide-name.zip
├── veeva-library.js              ← downloaded in step 1
├── veeva-segment-navigation.html ← the main HTML file
└── (any images/css if needed)
```

**Important:** The HTML file and `veeva-library.js` must be at the **root** of the ZIP (not inside a subfolder).

### 5. Upload to Vault / CRM

Upload the ZIP as a Key Message / Multichannel Slide in your Veeva system.

---

## How the Code Works

```
User taps "Segment A"
        │
        ▼
playSegment("A")
        │
        ▼
Looks up segments["A"] → ["BrandX_2024_01", "BrandX_2024_03", ...]
        │
        ▼
Takes the first slide → "BrandX_2024_01"
        │
        ▼
com.veeva.clm.gotoSlide("BrandX_2024_01", "")
        │
        ▼
Veeva CLM player navigates to that slide
```

The second parameter `""` means "stay in the current presentation."

---

## Debugging (Since Veeva Shows No Errors)

The HTML file includes a **green-on-black debug panel** at the bottom of the screen. It will show messages like:

| Message | Meaning |
|---------|---------|
| `OK: veeva-library.js loaded successfully` | Library is working |
| `ERROR: com.veeva.clm is UNDEFINED` | **Library is missing** from the ZIP |
| `playSegment('A') → navigating to: slide_1` | Button tap is working |
| `SUCCESS: gotoSlide('slide_1', '') called` | API call was made |
| `EXCEPTION: ...` | Something crashed — read the message |

**Remove the debug panel before going to production** by deleting this from the HTML:

```html
<div id="debugLog"></div>
```

---

## Common Problems & Fixes

### Problem: Nothing happens when tapping buttons

| Check | Fix |
|-------|-----|
| Is `veeva-library.js` in the ZIP? | Download it and add it to the root of the ZIP |
| Is the `<script src="veeva-library.js">` tag present? | Add it in `<head>` before your own `<script>` |
| Are slide names correct? | Verify `Media_File_Name_vod__c` values in CRM/Vault |
| Are slide names **case-sensitive**? | Yes — `BrandX_01` ≠ `brandx_01` |
| Is the HTML inside a subfolder in the ZIP? | Move it to the root level |

### Problem: Works for some segments but not others

The slide names for the failing segment are wrong. Double-check each name in the `segments` object against the actual `Media_File_Name_vod__c` values.

### Problem: Debug panel says "com.veeva.clm is UNDEFINED"

The library file is not loading. Possible reasons:
1. `veeva-library.js` is not in the ZIP
2. The filename has a typo (e.g., `veeva-Library.js` — case matters)
3. The file is in a subfolder instead of root

### Problem: Debug panel says "SUCCESS" but slide doesn't change

The API call went through but the slide name doesn't match any slide in the presentation. Verify:
1. The slide name matches `Media_File_Name_vod__c` **exactly**
2. The slide belongs to the **same presentation** (since we pass `""`)

---

## API Reference (Quick)

```javascript
// Navigate to a slide in the CURRENT presentation
com.veeva.clm.gotoSlide("slide_key_name", "");

// Navigate to a slide in a DIFFERENT presentation
com.veeva.clm.gotoSlide("slide_key_name", "other_presentation_id");

// Go to next slide in display order
com.veeva.clm.nextSlide();

// Go to previous slide in display order
com.veeva.clm.prevSlide();
```

Source: [Veeva CLM Developer Docs](https://developer.veevacrm.com/doc/Content/CRM_topics/Veeva/clm-veeva.htm)

---

## Checklist Before Sending to Lead Developer

- [ ] Downloaded `veeva-library.js` and placed in ZIP root
- [ ] Replaced ALL placeholder slide names with real `Media_File_Name_vod__c` values
- [ ] Verified slide names are **exact** (case-sensitive)
- [ ] ZIP structure is flat (no subfolders)
- [ ] Tested on iPad / Veeva CLM player
- [ ] Debug panel shows `OK: veeva-library.js loaded successfully`
- [ ] Removed debug panel for production
